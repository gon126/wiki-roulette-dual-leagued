import { useState, useEffect, useCallback } from 'react';
import { Globe, RotateCcw, ChevronLeft, ChevronRight, ExternalLink, Languages } from 'lucide-react';

type Lang = 'he' | 'en';

interface Translations {
  title: string;
  subtitle: string;
  spinButton: string;
  loading: string;
  error: string;
  keyboardHint: string;
  madeBy: string;
  openInNewTab: string;
  prevArticle: string;
  nextArticle: string;
}

const translations: Record<Lang, Translations> = {
  he: {
    title: 'רולטת ויקי',
    subtitle: 'גלו מאמרים אקראיים מוויקיפדיה',
    spinButton: 'מאמר אקראי',
    loading: 'טוען מאמר...',
    error: 'שגיאה בטעינת המאמר',
    keyboardHint: 'השתמשו בחיצים ← → כדי לנווט',
    madeBy: 'נוצר בהשראת',
    openInNewTab: 'פתח בלשונית חדשה',
    prevArticle: 'מאמר קודם',
    nextArticle: 'מאמר הבא',
  },
  en: {
    title: 'WikiRoulette',
    subtitle: 'Discover random Wikipedia articles',
    spinButton: 'Random Article',
    loading: 'Loading article...',
    error: 'Error loading article',
    keyboardHint: 'Use ← → arrow keys to navigate',
    madeBy: 'Inspired by',
    openInNewTab: 'Open in new tab',
    prevArticle: 'Previous',
    nextArticle: 'Next',
  },
};

export default function App() {
  const [lang, setLang] = useState<Lang>('he');
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isLoading, setIsLoading] = useState(false);

  const t = translations[lang];

  const getRandomUrl = useCallback(() => {
    return lang === 'he'
      ? 'https://he.wikipedia.org/wiki/מיוחד:אקראי'
      : 'https://en.wikipedia.org/wiki/Special:Random';
  }, [lang]);

  const fetchRandomArticle = useCallback(async () => {
    setIsLoading(true);
    
    try {
      const randomUrl = getRandomUrl();
      const response = await fetch(randomUrl, { method: 'HEAD', redirect: 'manual' });
      
      let finalUrl = randomUrl;
      if (response.type === 'opaqueredirect' || response.redirected) {
        finalUrl = response.url || randomUrl;
      }
      
      // For Wikipedia random, we need to open in new way since CORS blocks iframe
      // We'll simulate by opening in new tab
      setCurrentUrl(finalUrl);
      
      // Add to history
      setHistory(prev => {
        const newHistory = prev.slice(0, historyIndex + 1);
        newHistory.push(finalUrl);
        return newHistory;
      });
      setHistoryIndex(prev => prev + 1);
      
      // Open the article in new tab
      window.open(finalUrl, '_blank');
    } catch (error) {
      // Fallback: just open the random URL
      const url = getRandomUrl();
      setCurrentUrl(url);
      window.open(url, '_blank');
    } finally {
      setIsLoading(false);
    }
  }, [getRandomUrl, historyIndex]);

  const goBack = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const url = history[newIndex];
      setCurrentUrl(url);
      window.open(url, '_blank');
    }
  }, [history, historyIndex]);

  const goForward = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      const url = history[newIndex];
      setCurrentUrl(url);
      window.open(url, '_blank');
    }
  }, [history, historyIndex]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        goBack();
      } else if (e.key === 'ArrowRight') {
        if (historyIndex < history.length - 1) {
          goForward();
        } else {
          fetchRandomArticle();
        }
      } else if (e.key === ' ') {
        e.preventDefault();
        fetchRandomArticle();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [fetchRandomArticle, goBack, goForward, historyIndex, history.length]);

  const toggleLang = () => {
    setLang(prev => prev === 'he' ? 'en' : 'he');
  };

  const openCurrentInNewTab = () => {
    if (currentUrl) {
      window.open(currentUrl, '_blank');
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-50 via-white to-zinc-100 transition-all duration-300 ${lang === 'he' ? 'rtl' : 'ltr'}`} dir={lang === 'he' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-800">{t.title}</h1>
          </div>
          
          <button
            onClick={toggleLang}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors font-medium"
          >
            <Languages className="w-4 h-4" />
            <span>{lang === 'he' ? 'English' : 'עברית'}</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-32 pb-16 px-4">
        <div className="max-w-2xl mx-auto text-center">
          {/* Hero */}
          <div className="mb-12">
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-200 animate-pulse">
              <RotateCcw className={`w-12 h-12 text-white ${isLoading ? 'animate-spin' : ''}`} />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
              {t.title}
            </h2>
            <p className="text-lg text-slate-500">
              {t.subtitle}
            </p>
          </div>

          {/* Main Button */}
          <div className="mb-8">
            <button
              onClick={fetchRandomArticle}
              disabled={isLoading}
              className="group relative inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-lg font-semibold rounded-2xl shadow-xl shadow-emerald-200 hover:shadow-2xl hover:shadow-emerald-300 hover:scale-105 active:scale-95 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RotateCcw className={`w-6 h-6 ${isLoading ? 'animate-spin' : 'group-hover:rotate-180'} transition-transform duration-500`} />
              <span>{isLoading ? t.loading : t.spinButton}</span>
            </button>
          </div>

          {/* Navigation Buttons */}
          {history.length > 0 && (
            <div className="flex items-center justify-center gap-4 mb-8">
              <button
                onClick={goBack}
                disabled={historyIndex <= 0}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
                <span>{t.prevArticle}</span>
              </button>
              
              <span className="text-slate-400 text-sm">
                {historyIndex + 1} / {history.length}
              </span>
              
              <button
                onClick={goForward}
                disabled={historyIndex >= history.length - 1}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed text-slate-700 transition-colors"
              >
                <span>{t.nextArticle}</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {/* Current Article Info */}
          {currentUrl && (
            <div className="mb-8 p-6 bg-white rounded-2xl shadow-lg border border-slate-100">
              <p className="text-sm text-slate-400 mb-2">{lang === 'he' ? 'מאמר נוכחי:' : 'Current Article:'}</p>
              <p className="text-slate-600 truncate mb-4" dir="ltr">{currentUrl}</p>
              <button
                onClick={openCurrentInNewTab}
                className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-medium transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                <span>{t.openInNewTab}</span>
              </button>
            </div>
          )}

          {/* Keyboard Hint */}
          <div className="flex items-center justify-center gap-2 text-slate-400 text-sm">
            <span className="px-2 py-1 bg-slate-100 rounded text-slate-500 font-mono text-xs">←</span>
            <span className="px-2 py-1 bg-slate-100 rounded text-slate-500 font-mono text-xs">→</span>
            <span>{t.keyboardHint}</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 py-4 text-center text-slate-400 text-sm bg-gradient-to-t from-slate-50 to-transparent">
        <p>
          {t.madeBy}{' '}
          <a 
            href="https://wikiroulette.co" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-emerald-600 hover:text-emerald-700 font-medium"
          >
            WikiRoulette
          </a>
        </p>
      </footer>
    </div>
  );
}
